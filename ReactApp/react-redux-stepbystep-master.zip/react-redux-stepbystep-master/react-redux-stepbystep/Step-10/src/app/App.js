import {render} from "react-dom";
import React from "react";

const App  = () =>(
            <div>
                <h1>Testing Component</h1>
            </div>
        )

export default App;